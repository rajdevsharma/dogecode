import math

def roundup(x):
    return int(math.ceil(x / 10.0)) * 10